#!/bin/bash

# Быстрый доступ к панели Marzban через SSH туннель

echo "🔗 Создание SSH туннеля для доступа к Marzban..."
echo ""
echo "Панель будет доступна по адресу: http://localhost:8000"
echo ""
echo "Нажмите Ctrl+C для остановки туннеля"
echo ""

# Использование sshpass для автоматического ввода пароля
if command -v sshpass &> /dev/null; then
    sshpass -p "LEJ6U5chSK" ssh -L 8000:127.0.0.1:8000 -o StrictHostKeyChecking=no root@37.1.212.51
else
    echo "⚠️  sshpass не установлен. Используется обычный SSH (потребуется ввод пароля)"
    echo "Пароль: LEJ6U5chSK"
    ssh -L 8000:127.0.0.1:8000 -o StrictHostKeyChecking=no root@37.1.212.51
fi
