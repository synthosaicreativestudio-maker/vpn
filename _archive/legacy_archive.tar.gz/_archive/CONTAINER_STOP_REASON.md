# 🔍 Причина остановки контейнера Marzban

## 📋 Анализ логов

### Ключевая информация из логов Docker:

```
Jan 19 12:23:34 ... level=warning msg="ShouldRestart failed, container will not be restarted" 
container=e86ff700e82956a2fed134e9bf6551d879c439a539c06cb52ca99150a5a6185d 
error="restart canceled" 
execDuration=47.338029136s 
exitStatus="{0 2026-01-19 12:23:34.752859668 +0000 UTC}" 
hasBeenManuallyStopped=true 
restartCount=5
```

### Детали остановки:

- **Время остановки:** 19 января 2026, 12:23:34 UTC (примерно 3 часа назад)
- **Exit Code:** 0 (нормальное завершение, не ошибка)
- **hasBeenManuallyStopped:** `true` ⚠️ **КЛЮЧЕВОЙ МОМЕНТ**
- **restartCount:** 5 (было 5 попыток перезапуска)
- **restart canceled:** Перезапуск был отменен

---

## 🎯 Причина остановки

**Контейнер был остановлен ВРУЧНУЮ** (`hasBeenManuallyStopped=true`)

### Возможные сценарии:

1. **Остановка через панель is*hosting**
   - Кто-то нажал кнопку "Выключить" или "Перезагрузить" в панели управления
   - Или использовал функцию остановки контейнера

2. **Остановка через команду**
   - Выполнена команда `docker stop marzban-marzban-1`
   - Или `docker compose stop` в директории `/opt/marzban`

3. **Автоматическая остановка при перезагрузке сервера**
   - Но сервер не перезагружался (последняя перезагрузка была 16 декабря)

---

## ⚠️ Почему контейнер не перезапустился автоматически?

**Политика перезапуска:** `restart: always` ✅ (настроена правильно)

**НО:** Когда контейнер останавливается **вручную** (`docker stop` или через панель), Docker **НЕ перезапускает** его автоматически, даже с политикой `always`.

Это стандартное поведение Docker - ручная остановка имеет приоритет над политикой автозапуска.

---

## ✅ Решение

### 1. Контейнер уже запущен (исправлено)

### 2. Чтобы предотвратить проблему в будущем:

**Вариант A: Настроить автозапуск через systemd** (рекомендуется)

Создайте systemd сервис, который будет следить за контейнером:

```bash
cat > /etc/systemd/system/marzban.service << 'EOF'
[Unit]
Description=Marzban VPN Service
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/marzban
ExecStart=/usr/bin/docker compose up -d
ExecStop=/usr/bin/docker compose stop
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable marzban.service
systemctl start marzban.service
```

**Вариант B: Мониторинг через cron**

Добавьте проверку каждые 5 минут:

```bash
crontab -e
# Добавьте строку:
*/5 * * * * docker ps | grep -q marzban-marzban-1 || (cd /opt/marzban && docker compose up -d)
```

**Вариант C: Просто проверяйте периодически**

Если контейнер остановится снова, запустите:
```bash
cd /opt/marzban && docker compose up -d
```

---

## 📊 Текущий статус

- ✅ Контейнер запущен
- ✅ Порт 443 слушается
- ✅ VPN работает
- ⚠️ Автозапуск при ручной остановке не работает (это нормально для Docker)

---

## 💡 Рекомендации

1. **Не останавливайте контейнер вручную**, если не планируете его перезапустить
2. **Используйте `docker compose restart`** вместо `stop`, если нужно перезапустить
3. **Настройте systemd сервис** для автоматического восстановления
4. **Проверяйте статус** периодически: `docker ps | grep marzban`

---

**Вывод:** Контейнер был остановлен вручную (через панель или команду), а не из-за ошибки или сбоя системы.
