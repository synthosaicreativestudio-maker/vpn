# 🔐 Настройка VLESS + REALITY для Marzban

## 📋 Описание

Данная инструкция описывает настройку нового Inbound в Marzban для работы через протокол VLESS с маскировкой REALITY на порту 443. Это позволит обходить блокировки, маскируя трафик под популярный сайт (Microsoft или Google).

**Важно:** На сервере уже работает TinyProxy на порту 8080. Порт 8080 не затрагивается данной настройкой.

---

## 🔑 Шаг 1: Генерация ключей REALITY

Выполните следующую команду внутри контейнера Marzban для генерации пары ключей (Private/Public):

```bash
docker exec -it marzban xray x25519
```

**Пример вывода:**
```
Private: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
Public:  yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy
```

**Сохраните оба ключа!** Они понадобятся для конфигурации.

---

## 📝 Шаг 2: JSON-конфигурация для Inbounds

Скопируйте следующий JSON-объект и добавьте его в массив `inbounds` в разделе **Core Settings** панели Marzban.

### Вариант 1: Маскировка под Microsoft (рекомендуется)

```json
{
  "tag": "VLESS-Reality-Microsoft",
  "protocol": "vless",
  "listen": "0.0.0.0",
  "port": 443,
  "settings": {
    "clients": [],
    "decryption": "none"
  },
  "streamSettings": {
    "network": "tcp",
    "security": "reality",
    "realitySettings": {
      "show": false,
      "dest": "www.microsoft.com:443",
      "xver": 0,
      "serverNames": [
        "www.microsoft.com",
        "microsoft.com"
      ],
      "privateKey": "ВАШ_PRIVATE_KEY_ЗДЕСЬ",
      "shortIds": [
        ""
      ],
      "minClientVer": "",
      "maxClientVer": "",
      "maxTimeDiff": 0,
      "publicKey": "ВАШ_PUBLIC_KEY_ЗДЕСЬ"
    },
    "tcpSettings": {
      "acceptProxyProtocol": false,
      "header": {
        "type": "none"
      }
    }
  },
  "sniffing": {
    "enabled": true,
    "destOverride": [
      "http",
      "tls"
    ]
  }
}
```

### Вариант 2: Маскировка под Google

```json
{
  "tag": "VLESS-Reality-Google",
  "protocol": "vless",
  "listen": "0.0.0.0",
  "port": 443,
  "settings": {
    "clients": [],
    "decryption": "none"
  },
  "streamSettings": {
    "network": "tcp",
    "security": "reality",
    "realitySettings": {
      "show": false,
      "dest": "www.google.com:443",
      "xver": 0,
      "serverNames": [
        "www.google.com",
        "google.com"
      ],
      "privateKey": "ВАШ_PRIVATE_KEY_ЗДЕСЬ",
      "publicKey": "ВАШ_PUBLIC_KEY_ЗДЕСЬ",
      "shortIds": [
        ""
      ],
      "minClientVer": "",
      "maxClientVer": "",
      "maxTimeDiff": 0
    },
    "tcpSettings": {
      "acceptProxyProtocol": false,
      "header": {
        "type": "none"
      }
    }
  },
  "sniffing": {
    "enabled": true,
    "destOverride": [
      "http",
      "tls"
    ]
  }
}
```

### ⚠️ Важно перед вставкой:

1. **Замените `ВАШ_PRIVATE_KEY_ЗДЕСЬ`** на Private Key, полученный в Шаге 1
2. **Замените `ВАШ_PUBLIC_KEY_ЗДЕСЬ`** на Public Key, полученный в Шаге 1
3. Если в `inbounds` уже есть конфигурация на порту 443, **удалите или замените её** на новую
4. Порт 8080 (TinyProxy) **не затрагивается** — он управляется отдельным сервисом

---

## 👤 Шаг 3: Создание пользователя в Marzban

1. Зайдите в панель Marzban
2. Перейдите в раздел **Users** (Пользователи)
3. Нажмите **Add User** (Добавить пользователя)
4. Заполните данные:
   - **Username**: любое имя пользователя
   - **Protocol**: выберите **VLESS**
   - **Flow**: выберите **vision** (xtls-rprx-vision)
   - **Inbound**: выберите созданный ранее **VLESS-Reality-Microsoft** (или Google)
5. Сохраните пользователя

После создания пользователя Marzban автоматически сгенерирует ссылку подключения в формате `vless://...`

---

## 🔗 Шаг 4: Формат ссылки vless://

Ссылка, которую вы получите в Marzban, будет выглядеть примерно так:

```
vless://uuid@your-server-ip:443?type=tcp&security=reality&sni=www.microsoft.com&pbk=ВАШ_PUBLIC_KEY&fp=chrome&flow=xtls-rprx-vision#VLESS-Reality
```

### Структура ссылки:

- `vless://` — протокол
- `uuid` — UUID пользователя (генерируется Marzban)
- `your-server-ip:443` — IP вашего сервера и порт 443
- `type=tcp` — тип соединения
- `security=reality` — использование REALITY
- `sni=www.microsoft.com` — SNI (Server Name Indication) для маскировки
- `pbk=ВАШ_PUBLIC_KEY` — Public Key из Шага 1
- `fp=chrome` — отпечаток браузера (fingerprint)
- `flow=xtls-rprx-vision` — поток для обхода блокировок
- `#VLESS-Reality` — название подключения (опционально)

---

## 📱 Шаг 5: Подключение через Amnezia VPN

### На Android/iOS:

1. Откройте приложение **Amnezia VPN**
2. Нажмите **"Добавить сервер"** или **"+"**
3. Выберите **"Из буфера обмена"** или **"Import from clipboard"**
4. Вставьте ссылку `vless://...`, скопированную из Marzban
5. Нажмите **Подключиться**

### На Windows/Mac:

1. Откройте приложение **Amnezia VPN**
2. Нажмите **"Добавить подключение"**
3. Выберите **"Импорт из буфера обмена"**
4. Вставьте ссылку `vless://...`
5. Сохраните и подключитесь

---

## 🔍 Проверка работы

### 1. Проверка порта 443:

```bash
# Проверьте, что порт 443 слушается
sudo netstat -tlnp | grep 443
# или
sudo ss -tlnp | grep 443
```

Должно быть видно, что порт 443 слушается процессом xray (внутри контейнера Marzban).

### 2. Проверка логов Marzban:

```bash
docker logs marzban -f
```

При успешном подключении клиента вы увидите логи подключений.

### 3. Проверка через Amnezia:

- Подключитесь через Amnezia
- Откройте браузер и перейдите на https://ip-api.com
- Проверьте, что ваш IP изменился на IP вашего VPS сервера

---

## ⚠️ Важные замечания

### Безопасность:

1. **Не публикуйте** Private Key и Public Key в открытых источниках
2. **Не делитесь** ссылкой `vless://` публично — она содержит UUID пользователя
3. Регулярно **обновляйте ключи** REALITY для повышения безопасности

### Производительность:

- REALITY работает быстрее, чем обычный TLS, так как не требует реального TLS handshake
- Порт 443 используется для маскировки под HTTPS трафик
- Трафик выглядит как обычное HTTPS соединение с Microsoft/Google

### Совместимость:

- **Порт 8080 (TinyProxy)** продолжает работать независимо
- **Порт 443 (VLESS REALITY)** работает параллельно
- Оба сервиса не конфликтуют, так как используют разные порты

---

## 🛠️ Устранение неполадок

### Проблема: Порт 443 уже занят

**Решение:**
1. Проверьте, какой процесс занимает порт 443:
   ```bash
   sudo lsof -i :443
   ```
2. Если это старый конфиг Marzban, удалите его из `inbounds`
3. Если это другой сервис (например, nginx/apache), остановите его или измените порт

### Проблема: Не подключается через Amnezia

**Проверьте:**
1. Правильность Public Key в ссылке `vless://`
2. Правильность SNI (должен совпадать с `serverNames` в конфиге)
3. Правильность Flow (`xtls-rprx-vision`)
4. Открыт ли порт 443 в файрволе:
   ```bash
   sudo ufw allow 443/tcp
   # или
   sudo firewall-cmd --add-port=443/tcp --permanent
   sudo firewall-cmd --reload
   ```

### Проблема: Трафик не проходит

**Проверьте:**
1. Логи Marzban на наличие ошибок
2. Правильность UUID пользователя
3. Активен ли пользователь в Marzban
4. Не превышен ли лимит трафика пользователя

---

## 📚 Дополнительная информация

### Альтернативные SNI для маскировки:

Если `www.microsoft.com` или `www.google.com` заблокированы, можно использовать:

- `www.cloudflare.com`
- `www.apple.com`
- `www.amazon.com`
- `www.facebook.com`

Просто замените `dest` и `serverNames` в JSON конфигурации.

### Генерация Short ID (опционально):

Для дополнительной безопасности можно сгенерировать Short ID:

```bash
openssl rand -hex 8
```

И добавить его в массив `shortIds` в конфигурации.

---

## 📝 История изменений

- **2026-01-12** - Создана инструкция по настройке VLESS + REALITY для Marzban
- Настроен порт 443 для обхода блокировок с маскировкой под популярные сайты

---

**Успешной настройки! 🚀**
