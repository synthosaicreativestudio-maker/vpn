# 🧠 Объяснение правил маршрутизации (Сценарий 2: Умный обход для РФ)

## 📋 Обзор

Данный документ детально объясняет правила маршрутизации в конфигурации `client_config_smart_routing_ru.json`.

## 🔄 Принцип работы

Правила маршрутизации обрабатываются **сверху вниз** (по порядку). Первое совпадающее правило применяется, остальные игнорируются.

---

## 📐 Структура правил

### 1. Локальные адреса → DIRECT

```json
{
  "type": "field",
  "ip": [
    "0.0.0.0/8",      // Локальная сеть
    "10.0.0.0/8",     // Приватная сеть класса A
    "127.0.0.0/8",    // Loopback (localhost)
    "192.168.0.0/16", // Приватная сеть класса C
    "::1/128",        // IPv6 localhost
    "fc00::/7",       // IPv6 приватная сеть
    "fe80::/10"       // IPv6 link-local
  ],
  "outboundTag": "direct"
}
```

**Назначение:** Локальные адреса (ваш компьютер, роутер, локальная сеть) всегда идут напрямую, без VPN.

**Примеры:**
- `127.0.0.1` (localhost) → DIRECT
- `192.168.1.1` (роутер) → DIRECT
- `10.0.0.5` (локальный сервер) → DIRECT

---

### 2. Российские IP адреса → DIRECT

```json
{
  "type": "field",
  "ip": ["geoip:ru"],
  "outboundTag": "direct"
}
```

**Назначение:** Все IP адреса, принадлежащие России, идут напрямую.

**Как работает:**
- Клиент использует базу данных GeoIP
- Определяет страну по IP адресу
- Если страна = RU → DIRECT

**Примеры:**
- `5.8.47.0` (Yandex) → DIRECT
- `87.250.250.242` (Yandex) → DIRECT
- `213.180.204.3` (Yandex) → DIRECT

---

### 3. Российские домены → DIRECT

```json
{
  "type": "field",
  "domain": ["geosite:ru"],
  "outboundTag": "direct"
}
```

**Назначение:** Все домены из категории "ru" идут напрямую.

**Что включает:**
- Все `.ru` домены
- Популярные российские сайты
- Российские сервисы

**Примеры:**
- `yandex.ru` → DIRECT
- `mail.ru` → DIRECT
- `sberbank.ru` → DIRECT
- `gosuslugi.ru` → DIRECT

---

### 4. Yandex → DIRECT

```json
{
  "type": "field",
  "domain": ["geosite:yandex"],
  "outboundTag": "direct"
}
```

**Назначение:** Все сервисы Yandex идут напрямую.

**Что включает:**
- yandex.ru, yandex.com, yandex.net
- ya.ru
- Все поддомены Yandex
- Yandex Maps, Yandex Music, Yandex Disk и т.д.

**Примеры:**
- `yandex.ru` → DIRECT
- `maps.yandex.ru` → DIRECT
- `music.yandex.ru` → DIRECT
- `disk.yandex.ru` → DIRECT

---

### 5. Mail.ru → DIRECT

```json
{
  "type": "field",
  "domain": ["geosite:mailru"],
  "outboundTag": "direct"
}
```

**Назначение:** Все сервисы Mail.ru идут напрямую.

**Что включает:**
- mail.ru
- my.mail.ru
- ok.ru (Одноклассники)
- Все поддомены Mail.ru

**Примеры:**
- `mail.ru` → DIRECT
- `my.mail.ru` → DIRECT
- `ok.ru` → DIRECT
- `games.mail.ru` → DIRECT

---

### 6. VK (ВКонтакте) → DIRECT

```json
{
  "type": "field",
  "domain": ["geosite:vk"],
  "outboundTag": "direct"
}
```

**Назначение:** ВКонтакте идет напрямую.

**Что включает:**
- vk.com
- vk.ru
- Все поддомены VK

**Примеры:**
- `vk.com` → DIRECT
- `vk.ru` → DIRECT
- `api.vk.com` → DIRECT

---

### 7. Госуслуги → DIRECT

```json
{
  "type": "field",
  "domain": ["geosite:category-gov-ru"],
  "outboundTag": "direct"
}
```

**Назначение:** Государственные сервисы России идут напрямую.

**Что включает:**
- gosuslugi.ru (Госуслуги)
- nalog.ru (ФНС)
- pfr.gov.ru (Пенсионный фонд)
- fss.ru (ФСС)
- Все государственные сайты РФ

**Примеры:**
- `gosuslugi.ru` → DIRECT
- `nalog.ru` → DIRECT
- `pfr.gov.ru` → DIRECT
- `fss.ru` → DIRECT

---

### 8. Банки → DIRECT

```json
{
  "type": "field",
  "domain": ["geosite:category-bank-ru"],
  "outboundTag": "direct"
}
```

**Назначение:** Российские банки идут напрямую.

**Что включает:**
- sberbank.ru (Сбербанк)
- tinkoff.ru (Тинькофф)
- alfabank.ru (Альфа-Банк)
- vtb.ru (ВТБ)
- gazprombank.ru (Газпромбанк)
- raiffeisen.ru (Райффайзен)
- rosbank.ru (Росбанк)
- И другие российские банки

**Примеры:**
- `sberbank.ru` → DIRECT
- `online.sberbank.ru` → DIRECT
- `tinkoff.ru` → DIRECT
- `alfabank.ru` → DIRECT

---

### 9. Telegram → DIRECT

```json
{
  "type": "field",
  "domain": ["geosite:telegram"],
  "outboundTag": "direct"
}
```

**Назначение:** Telegram идет напрямую (работает в РФ без VPN).

**Что включает:**
- telegram.org
- telegram.me
- t.me
- Все серверы Telegram

**Примеры:**
- `telegram.org` → DIRECT
- `t.me` → DIRECT
- `api.telegram.org` → DIRECT

---

### 10. Реклама → Блокировка

```json
{
  "type": "field",
  "domain": [
    "geosite:category-ads-all",
    "geosite:category-ads"
  ],
  "outboundTag": "block"
}
```

**Назначение:** Блокировка рекламных доменов.

**Что включает:**
- doubleclick.net
- googlesyndication.com
- googleadservices.com
- И другие рекламные сети

**Результат:** Запросы к рекламным доменам блокируются (blackhole).

---

### 11. Всё остальное → VPN (PROXY)

```json
{
  "type": "field",
  "network": "tcp,udp",
  "outboundTag": "proxy"
}
```

**Назначение:** Всё, что не попало под предыдущие правила, идет через VPN.

**Что включает:**
- Зарубежные сайты (Google, Facebook, Twitter и др.)
- Заблокированные в РФ сайты
- Международные сервисы
- Весь остальной трафик

**Примеры:**
- `google.com` → PROXY (VPN)
- `facebook.com` → PROXY (VPN)
- `twitter.com` → PROXY (VPN)
- `github.com` → PROXY (VPN)

---

## 🔍 Порядок проверки правил

```
Запрос → Правило 1 (локальные IP)?
         ├─ Да → DIRECT ✅
         └─ Нет → Правило 2 (geoip:ru)?
                  ├─ Да → DIRECT ✅
                  └─ Нет → Правило 3 (geosite:ru)?
                           ├─ Да → DIRECT ✅
                           └─ Нет → Правило 4 (yandex)?
                                    ├─ Да → DIRECT ✅
                                    └─ Нет → ... (и так далее)
                                                      └─ Последнее правило → PROXY ✅
```

---

## 🌐 DNS настройки

### Для зарубежных доменов:
- **DNS:** 8.8.8.8 (Google)
- **Использование:** Через VPN

### Для российских доменов:
- **DNS:** 77.88.8.8 (Yandex DNS)
- **Использование:** Напрямую

### Fallback:
- **DNS:** 1.1.1.1 (Cloudflare)
- **Использование:** Резервный

---

## 📊 Примеры работы

### Пример 1: Открытие sberbank.ru

1. DNS запрос → `sberbank.ru` → Правило 8 (банки) → DIRECT
2. IP запрос → `194.54.14.131` → Правило 2 (geoip:ru) → DIRECT
3. **Результат:** Сайт открывается напрямую, без VPN

### Пример 2: Открытие google.com

1. DNS запрос → `google.com` → Не попадает под правила 1-10
2. Применяется последнее правило → PROXY
3. **Результат:** Сайт открывается через VPN

### Пример 3: Открытие yandex.ru

1. DNS запрос → `yandex.ru` → Правило 3 (geosite:ru) → DIRECT
2. Или → Правило 4 (geosite:yandex) → DIRECT
3. **Результат:** Сайт открывается напрямую

---

## ⚙️ Настройка geosite файлов

Для работы правил `geosite:*` нужны файлы базы данных:

- **geosite.dat** - база доменов
- **geoip.dat** - база IP адресов

**Где взять:**
- Автоматически загружаются клиентами (v2rayNG, v2rayN и др.)
- Или вручную: https://github.com/v2fly/domain-list-community
- Или: https://github.com/Loyalsoldier/v2ray-rules-dat

**Обновление:**
- Обычно клиенты обновляют автоматически
- Или вручную через настройки клиента

---

## 🔧 Кастомизация правил

### Добавить свой домен в DIRECT:

```json
{
  "type": "field",
  "domain": ["example.com", "*.example.com"],
  "outboundTag": "direct"
}
```

### Добавить IP диапазон в DIRECT:

```json
{
  "type": "field",
  "ip": ["192.0.2.0/24"],
  "outboundTag": "direct"
}
```

### Блокировать домен:

```json
{
  "type": "field",
  "domain": ["malicious-site.com"],
  "outboundTag": "block"
}
```

---

## ✅ Проверка правил

### Тест 1: Российский сайт
```bash
curl -x socks5://127.0.0.1:1080 https://yandex.ru
# Должен идти напрямую (не через VPN)
```

### Тест 2: Зарубежный сайт
```bash
curl -x socks5://127.0.0.1:1080 https://google.com
# Должен идти через VPN
```

### Тест 3: Проверка IP
- Российский сайт (2ip.ru) → Ваш реальный IP
- Зарубежный сайт (ip-api.com) → 37.1.212.51 (IP сервера)

---

## 📝 Важные замечания

1. **Порядок правил важен** - первое совпадающее правило применяется
2. **geosite файлы** должны быть актуальными
3. **DNS утечки** - используйте правильные DNS настройки
4. **Производительность** - локальный трафик быстрее через DIRECT

---

**Правила настроены для оптимального баланса скорости и функциональности! 🚀**
