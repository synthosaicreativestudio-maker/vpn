# 🔒 Отчет по безопасности и оптимизации сервера 37.1.212.51

**Дата исследования:** 29 января 2026  
**Использованные скиллы:** security_auditing, best_practices_search, risk_forecasting, security_preflight

---

## 📊 Диагностированные проблемы

### 1. **Критическая уязвимость: TinyProxy открыт для всего мира**
- **Текущая конфигурация:** `Allow 0.0.0.0/0` в `/etc/tinyproxy/tinyproxy.conf`
- **Последствия:**
  - 332+ активных соединения от неизвестных IP
  - Сервер используется как бесплатный прокси-хостел
  - Боты и сканеры обходят BasicAuth через утечки или брутфорс
  - Израильские IP (81.218.83.97) и другие используют ваш сервер

### 2. **Исчерпание ресурсов**
- **Память:** 1 ГБ RAM полностью использован
- **Swap:** Активно используется, что замедляет все процессы
- **Причина:** Сотни паразитных соединений через TinyProxy

### 3. **Отсутствие защиты от DDoS**
- Нет rate limiting на уровне TinyProxy
- Нет ограничений на количество соединений с одного IP
- Нет автоматической блокировки подозрительных IP

---

## ✅ РЕШЕНИЯ (БЕЗ изменения настроек Яндекса и прокси)

### **Решение 1: Ограничение доступа к TinyProxy через UFW**

**Проблема:** TinyProxy доступен с любого IP в интернете.

**Решение:** Ограничить доступ к порту 8080 только для вашего IP (или списка доверенных IP).

```bash
# На сервере выполните:
# 1. Узнайте ваш текущий IP (с Mac)
curl -4 ifconfig.me

# 2. На сервере добавьте правило UFW (замените YOUR_IP на ваш IP)
ufw allow from YOUR_IP to any port 8080 proto tcp comment "TinyProxy access"

# 3. Если нужен доступ с нескольких IP (например, для бота):
ufw allow from IP1 to any port 8080 proto tcp comment "TinyProxy bot1"
ufw allow from IP2 to any port 8080 proto tcp comment "TinyProxy bot2"

# 4. Блокируем все остальные подключения к 8080
ufw deny 8080/tcp

# 5. Применяем правила
ufw reload
```

**Альтернатива (если IP динамический):** Используйте fail2ban для автоматической блокировки после нескольких неудачных попыток BasicAuth.

---

### **Решение 2: Настройка лимитов в TinyProxy**

**Проблема:** Нет ограничений на количество одновременных соединений.

**Решение:** Добавить параметры `MaxClients` и `MaxRequests` в конфиг TinyProxy.

```bash
# На сервере отредактируйте /etc/tinyproxy/tinyproxy.conf:

# Ограничение одновременных соединений (для MVP-бота достаточно 10-20)
MaxClients 20

# Ограничение запросов с одного соединения (предотвращает злоупотребление)
MaxRequests 100

# Таймаут неактивных соединений (освобождает ресурсы)
Timeout 600

# Перезапустите TinyProxy
systemctl restart tinyproxy
```

**Рекомендуемые значения:**
- `MaxClients: 20` — для MVP-бота достаточно
- `MaxRequests: 100` — предотвращает злоупотребление одним соединением
- `Timeout: 600` — закрывает неактивные соединения через 10 минут

---

### **Решение 3: Rate Limiting через iptables**

**Проблема:** Один IP может создавать сотни соединений.

**Решение:** Ограничить количество новых соединений в секунду с одного IP.

```bash
# На сервере выполните:

# 1. Создайте правило для ограничения новых соединений (5 в секунду)
iptables -A INPUT -p tcp --dport 8080 -m state --state NEW -m recent --set
iptables -A INPUT -p tcp --dport 8080 -m state --state NEW -m recent --update --seconds 1 --hitcount 5 -j DROP

# 2. Сохраните правила (Ubuntu)
iptables-save > /etc/iptables/rules.v4

# 3. Для автоматической загрузки при перезагрузке:
apt-get install iptables-persistent -y
```

**Альтернатива (через UFW):** UFW не поддерживает rate limiting напрямую, используйте iptables или fail2ban.

---

### **Решение 4: Установка и настройка fail2ban**

**Проблема:** Нет автоматической блокировки подозрительных IP.

**Решение:** Установить fail2ban для мониторинга логов TinyProxy и автоматической блокировки.

```bash
# На сервере:

# 1. Установите fail2ban
apt-get update && apt-get install fail2ban -y

# 2. Создайте конфиг для TinyProxy
cat > /etc/fail2ban/jail.d/tinyproxy.conf << 'EOF'
[tinyproxy]
enabled = true
port = 8080
filter = tinyproxy
logpath = /var/log/tinyproxy/tinyproxy.log
maxretry = 3
bantime = 3600
findtime = 600
EOF

# 3. Создайте фильтр для TinyProxy
cat > /etc/fail2ban/filter.d/tinyproxy.conf << 'EOF'
[Definition]
failregex = ^.*\[WARNING\].*Connection from <HOST> refused.*$
            ^.*\[ERROR\].*Connection from <HOST> failed.*$
ignoreregex =
EOF

# 4. Перезапустите fail2ban
systemctl restart fail2ban
systemctl enable fail2ban
```

---

### **Решение 5: Оптимизация использования памяти**

**Проблема:** 1 ГБ RAM недостаточно для сотен соединений.

**Решения:**

#### 5.1. Оптимизация Swap
```bash
# Увеличьте swappiness для более агрессивного использования Swap
echo 'vm.swappiness=10' >> /etc/sysctl.conf
sysctl -p
```

#### 5.2. Ограничение ресурсов для TinyProxy через systemd
```bash
# Отредактируйте /etc/systemd/system/tinyproxy.service или создайте override:
systemctl edit tinyproxy

# Добавьте:
[Service]
MemoryLimit=512M
CPUQuota=50%
TasksMax=50

# Примените изменения
systemctl daemon-reload
systemctl restart tinyproxy
```

#### 5.3. Мониторинг памяти
```bash
# Установите htop для мониторинга
apt-get install htop -y

# Создайте скрипт для автоматической перезагрузки TinyProxy при нехватке памяти
cat > /usr/local/bin/tinyproxy-memory-watchdog.sh << 'EOF'
#!/bin/bash
MEM_USAGE=$(free | grep Mem | awk '{printf "%.0f", $3/$2 * 100}')
if [ $MEM_USAGE -gt 90 ]; then
    systemctl restart tinyproxy
    echo "$(date): TinyProxy restarted due to high memory usage ($MEM_USAGE%)" >> /var/log/tinyproxy-watchdog.log
fi
EOF

chmod +x /usr/local/bin/tinyproxy-memory-watchdog.sh

# Добавьте в crontab (каждые 5 минут)
(crontab -l 2>/dev/null; echo "*/5 * * * * /usr/local/bin/tinyproxy-memory-watchdog.sh") | crontab -
```

---

### **Решение 6: Логирование и мониторинг**

**Проблема:** Нет видимости, кто использует прокси.

**Решение:** Включить детальное логирование и создать скрипт анализа.

```bash
# 1. Включите логирование в /etc/tinyproxy/tinyproxy.conf:
LogLevel Info
LogFile /var/log/tinyproxy/tinyproxy.log
StatFile /var/log/tinyproxy/tinyproxy.stats

# 2. Создайте скрипт для анализа подключений
cat > /usr/local/bin/analyze-tinyproxy-connections.sh << 'EOF'
#!/bin/bash
echo "=== Top 10 IP addresses using TinyProxy ==="
grep "Connect" /var/log/tinyproxy/tinyproxy.log | awk '{print $7}' | sort | uniq -c | sort -rn | head -10

echo ""
echo "=== Current active connections ==="
ss -tn | grep :8080 | wc -l

echo ""
echo "=== Memory usage ==="
free -h
EOF

chmod +x /usr/local/bin/analyze-tinyproxy-connections.sh
```

---

### **Решение 7: Замена Allow 0.0.0.0/0 на конкретные IP**

**Проблема:** `Allow 0.0.0.0/0` открывает доступ для всего мира.

**Решение:** Заменить на список доверенных IP (если известны IP вашего бота).

```bash
# В /etc/tinyproxy/tinyproxy.conf:

# Удалите строку:
# Allow 0.0.0.0/0

# Добавьте конкретные IP (замените на реальные IP вашего бота):
Allow 192.168.1.0/24
Allow 10.0.0.0/8
# Или конкретный IP:
Allow 123.45.67.89

# Перезапустите
systemctl restart tinyproxy
```

**⚠️ Внимание:** Если IP бота динамический, используйте UFW правила (Решение 1) вместо этого.

---

## 📋 Чек-лист внедрения

### Приоритет 1 (Критично - выполнить немедленно):
- [ ] **Решение 1:** Ограничить доступ к порту 8080 через UFW (только ваш IP)
- [ ] **Решение 2:** Добавить `MaxClients 20` в TinyProxy
- [ ] **Решение 3:** Настроить rate limiting через iptables

### Приоритет 2 (Важно - выполнить в течение дня):
- [ ] **Решение 4:** Установить и настроить fail2ban
- [ ] **Решение 5.2:** Ограничить память для TinyProxy через systemd
- [ ] **Решение 6:** Включить детальное логирование

### Приоритет 3 (Рекомендуется):
- [ ] **Решение 5.1:** Оптимизировать swappiness
- [ ] **Решение 5.3:** Настроить watchdog для автоматической перезагрузки
- [ ] **Решение 7:** Заменить `Allow 0.0.0.0/0` на конкретные IP (если известны)

---

## 🔍 Проверка эффективности

После внедрения решений проверьте:

```bash
# 1. Количество активных соединений (должно быть < 20)
ss -tn | grep :8080 | wc -l

# 2. Использование памяти (должно быть < 80%)
free -h

# 3. Статус fail2ban
fail2ban-client status tinyproxy

# 4. Логи TinyProxy (не должно быть массовых подключений)
tail -f /var/log/tinyproxy/tinyproxy.log
```

---

## ⚠️ Важные замечания

1. **Не трогайте настройки Яндекса:** VLESS+Reality на порту 443 с маскировкой `taxi.yandex.ru` работает корректно и не требует изменений.

2. **Не меняйте сам прокси:** TinyProxy работает правильно, проблема только в отсутствии ограничений доступа.

3. **Резервное копирование:** Перед изменениями создайте бэкап:
   ```bash
   cp /etc/tinyproxy/tinyproxy.conf /etc/tinyproxy/tinyproxy.conf.backup.$(date +%Y%m%d)
   ```

4. **Тестирование:** После каждого изменения проверяйте, что бот все еще может использовать прокси:
   ```bash
   curl -x http://root:LEJ6U5chSK@127.0.0.1:8080 https://api.ipify.org
   ```

---

## 📊 Ожидаемые результаты

После внедрения всех решений:
- ✅ Количество активных соединений: **< 20** (вместо 332+)
- ✅ Использование памяти: **< 60%** (вместо 100% + Swap)
- ✅ Подозрительные IP: **автоматически блокируются** fail2ban
- ✅ Производительность: **восстановлена**, Swap не используется активно
- ✅ Безопасность: **значительно повышена**, доступ только для авторизованных IP

---

**Дата создания:** 29 января 2026  
**Статус:** Готово к внедрению  
**Приоритет:** Критический
