# 🚨 VPN не работает - Быстрое решение

## Проблема
Не удалось автоматически подключиться к серверу для диагностики из-за проблем с SSH аутентификацией.

## ✅ Что нужно сделать СЕЙЧАС

### Шаг 1: Получите доступ к серверу

**Вариант A: Через SSH (если знаете правильный пароль)**
```bash
ssh root@37.1.212.51
# Введите пароль при запросе
```

**Вариант B: Через VPS панель провайдера**
- Войдите в панель управления вашего VPS провайдера
- Откройте консоль сервера (Console/VNC)
- Вы получите прямой доступ к терминалу сервера

### Шаг 2: Запустите диагностику

После получения доступа выполните команды:

```bash
# 1. Проверка Docker
docker ps | grep marzban

# 2. Если контейнер не запущен - запустите его
cd /opt/marzban
docker compose restart

# 3. Проверка порта 443
netstat -tlnp | grep 443

# 4. Проверка файрвола
ufw status | grep 443

# 5. Если порт 443 закрыт - откройте его
ufw allow 443/tcp
ufw reload

# 6. Проверка логов
docker logs marzban-marzban-1 --tail 50
```

### Шаг 3: Быстрое исправление (если нужно)

**Если Docker контейнер остановлен:**
```bash
cd /opt/marzban
docker compose up -d
```

**Если Docker не запущен:**
```bash
systemctl start docker
systemctl enable docker
cd /opt/marzban
docker compose up -d
```

**Если порт 443 закрыт в файрволе:**
```bash
ufw allow 443/tcp
ufw reload
```

**Если конфигурация повреждена:**
```bash
# Проверьте конфигурацию
cat /var/lib/marzban/xray_config.json | python3 -m json.tool

# Если есть ошибки - перезапустите Marzban
cd /opt/marzban
docker compose restart
```

---

## 📋 Альтернативный способ диагностики

Если у вас есть доступ к серверу через SSH, вы можете запустить готовый скрипт:

```bash
# На вашем локальном компьютере
cd /Users/verakoroleva/Desktop/vpn
./check_server_manual.sh
```

Этот скрипт автоматически подключится к серверу и выполнит все проверки.

---

## 🔍 Проверка работы VPN после исправления

1. **Подключитесь к VPN** через Amnezia или другой клиент
2. **Проверьте IP адрес:**
   - Откройте https://ifconfig.me
   - IP должен быть `37.1.212.51`

3. **Если IP не изменился:**
   - Проверьте настройки клиента
   - Попробуйте переподключиться
   - Проверьте логи на сервере: `docker logs marzban-marzban-1 -f`

---

## 📞 Если проблема не решена

Выполните полную диагностику и сохраните результаты:

```bash
# На сервере
docker ps -a > /tmp/docker_status.txt
docker logs marzban-marzban-1 > /tmp/marzban_logs.txt 2>&1
netstat -tlnp > /tmp/ports.txt
ufw status > /tmp/firewall.txt
cat /var/lib/marzban/xray_config.json > /tmp/xray_config.json

# Скачайте файлы для анализа
```

---

**Важно:** После исправления проблемы проверьте, что VPN работает, и сохраните рабочую конфигурацию.
