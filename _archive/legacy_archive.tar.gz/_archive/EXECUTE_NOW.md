# ⚡ ВЫПОЛНИТЬ СЕЙЧАС - Автоматическая настройка

## 🎯 Все готово! Выполните эти команды:

### Вариант 1: Полностью автоматический (если есть sshpass)

```bash
cd /Users/verakoroleva/Desktop/vpn
./run_setup.sh
```

### Вариант 2: Если sshpass не установлен (Mac)

```bash
# Установите sshpass
brew install hudochenkov/sshpass/sshpass

# Затем запустите
cd /Users/verakoroleva/Desktop/vpn
./run_setup.sh
```

### Вариант 3: Ручное выполнение (рекомендуется, если автоматика не работает)

#### Шаг 1: Скопируйте скрипт на сервер

```bash
cd /Users/verakoroleva/Desktop/vpn
scp auto_setup_reality_non_interactive.sh root@37.1.212.51:/tmp/
```

**Пароль:** `LEJ6U5chSK` (из PROXY_SETTINGS.md)

#### Шаг 2: Подключитесь к серверу и выполните

```bash
ssh root@37.1.212.51
```

**Пароль:** `LEJ6U5chSK`

На сервере выполните:

```bash
chmod +x /tmp/auto_setup_reality_non_interactive.sh
/tmp/auto_setup_reality_non_interactive.sh
```

#### Шаг 3: Скопируйте конфигурацию обратно

В новом терминале (на вашем компьютере):

```bash
scp root@37.1.212.51:/tmp/marzban_reality_config.json /Users/verakoroleva/Desktop/vpn/generated_config.json
```

#### Шаг 4: Вставьте конфигурацию в Marzban

1. Откройте файл `generated_config.json` (или скопируйте с сервера)
2. Откройте панель Marzban: `http://37.1.212.51:62050` (или другой порт)
3. Перейдите в **Core Settings**
4. Найдите `"inbounds": [ ... ]`
5. Вставьте JSON из `generated_config.json`
6. Сохраните

#### Шаг 5: Создайте пользователя

1. **Marzban → Users → Add User**
2. Заполните:
   - Protocol: **VLESS**
   - Flow: **vision**
   - Inbound: **VLESS-Reality-Microsoft**
3. Сохраните и скопируйте ссылку `vless://...`

#### Шаг 6: Подключитесь через Amnezia

1. Откройте **Amnezia VPN**
2. **Добавить сервер → Из буфера обмена**
3. Вставьте ссылку `vless://...`
4. Подключитесь

---

## ✅ Готово!

После выполнения всех шагов:
- ✅ TinyProxy на порту 8080 работает как раньше
- ✅ VLESS + REALITY на порту 443 настроен
- ✅ Можно подключаться через Amnezia VPN

---

## 📝 Все созданные файлы:

- `run_setup.sh` - Главный автоматический скрипт
- `auto_setup_reality_non_interactive.sh` - Скрипт для выполнения на сервере
- `execute_setup.py` - Python версия автоматизации
- `marzban_reality_config.json` - Шаблон конфигурации
- `generated_config.json` - Сгенерированная конфигурация (после выполнения)

---

**Начните с команды: `./run_setup.sh` 🚀**
