#!/bin/bash

# Скрипт для автоматического применения конфигурации в Marzban
# Использование: ./apply_config.sh [путь_к_конфигу.json]
# Требует доступа к файлам конфигурации Marzban

set -e

CONFIG_FILE="${1:-marzban_reality_config.json}"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "❌ Ошибка: Файл конфигурации не найден: $CONFIG_FILE"
    exit 1
fi

echo "🔧 Применение конфигурации VLESS + REALITY в Marzban"
echo "=================================================="
echo ""

# Поиск контейнера Marzban
CONTAINER_NAME=$(docker ps --format "{{.Names}}" | grep -i marzban | head -n 1)

if [ -z "$CONTAINER_NAME" ]; then
    echo "❌ Ошибка: Контейнер Marzban не найден"
    exit 1
fi

echo "✅ Найден контейнер: $CONTAINER_NAME"
echo ""

# Поиск файла конфигурации Marzban
MARZBAN_CONFIG_PATH=$(docker exec "$CONTAINER_NAME" find / -name "config.json" -o -name "xray_config.json" 2>/dev/null | head -n 1)

if [ -z "$MARZBAN_CONFIG_PATH" ]; then
    echo "⚠️  Автоматическое применение конфигурации требует ручного вмешательства"
    echo ""
    echo "📝 Инструкция:"
    echo "1. Откройте панель Marzban в браузере"
    echo "2. Перейдите в Core Settings"
    echo "3. Найдите раздел 'inbounds'"
    echo "4. Вставьте содержимое файла: $CONFIG_FILE"
    echo ""
    echo "Содержимое файла:"
    cat "$CONFIG_FILE"
    exit 0
fi

echo "✅ Найден файл конфигурации: $MARZBAN_CONFIG_PATH"
echo ""
echo "⚠️  ВНИМАНИЕ: Автоматическое редактирование конфигурации Marzban может быть опасным"
echo "   Рекомендуется использовать веб-интерфейс Marzban для добавления inbounds"
echo ""
read -p "Продолжить автоматическое применение? (y/n): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Отменено. Используйте веб-интерфейс Marzban для ручного добавления конфигурации."
    exit 0
fi

echo "📝 Конфигурация будет добавлена в: $MARZBAN_CONFIG_PATH"
echo "   (Резервная копия будет создана автоматически)"
echo ""

# Создание резервной копии
BACKUP_FILE="${MARZBAN_CONFIG_PATH}.backup.$(date +%Y%m%d_%H%M%S)"
docker exec "$CONTAINER_NAME" cp "$MARZBAN_CONFIG_PATH" "$BACKUP_FILE"
echo "✅ Резервная копия создана: $BACKUP_FILE"

echo ""
echo "⚠️  Для безопасности, рекомендуется добавлять конфигурацию через веб-интерфейс Marzban"
echo "   Файл конфигурации готов: $CONFIG_FILE"
echo "   Скопируйте его содержимое в раздел inbounds через панель управления"
