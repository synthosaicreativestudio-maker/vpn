# 🛠️ Техническая документация VPN-сервера

## 📌 Обзор проекта
Данный проект представляет собой высокопроизводительное и надежное решение для организации персонального VPN-сервера с маскировкой трафика и встроенным прокси-сервисом для интеграции с ИИ-сервисами (OpenAI API).

### Ключевые особенности:
*   **Протокол VLESS + REALITY:** Современный протокол, обеспечивающий высокую скорость и маскировку под обычный TLS-трафик (Microsoft).
*   **Панель Marzban:** Удобный интерфейс и API для управления пользователями и конфигурациями.
*   **TinyProxy:** Отдельный прокси-сервис для обхода региональных ограничений приложениями (например, MarketingBot).
*   **Модульность:** Возможность независимого управления сервисами (VPN, Proxy, Amnezia).

---

## 🏗️ Архитектура системы

```mermaid
graph TD
    User([Пользователь]) -- "VLESS + REALITY (Port 443)" --> Server[VPS Server 37.1.212.51]
    
    subgraph "Docker Environment"
        Marzban[Marzban Panel] -- "Управляет" --> Xray[Xray Core]
        Xray -- "VLESS + Reality" --> Port443[Port 443]
    end
    
    subgraph "System Services"
        TinyProxy[TinyProxy Port 8080]
        Amnezia[Amnezia WG/AWG]
    end
    
    MarketingBot[MarketingBot] -- "HTTP Proxy" --> TinyProxy
    TinyProxy -- "Запросы" --> OpenAI[OpenAI API]
    
    Marzban -- "Web UI (localhost:8000)" --> SSH[SSH Tunnel]
    SSH -- "Доступ" --> Admin([Администратор])
```

---

## 🖥️ Технический стек и сервер

### Характеристики сервера:
*   **ОС:** Ubuntu 22.04.4 LTS
*   **IP:** 37.1.212.51
*   **Расположение:** США (для доступа к сервисам, ограниченным в РФ)

### Установленное ПО:
| Компонент | Версия | Описание |
| :--- | :--- | :--- |
| **Docker** | 29.1.4 | Контейнеризация Marzban и Amnezia |
| **Xray Core** | 24.12.31 | Ядро VPN-сервиса (VLESS, Shadowsocks) |
| **Marzban** | latest | Панель управления пользователями |
| **TinyProxy** | Systemd service | HTTP-прокси для бота |

---

## 🔐 Настройка VPN (VLESS + REALITY)

Основной протокол доступа, настроенный на обход DPI и маскировку трафика.

### Параметры протокола:
*   **Порт:** `443`
*   **Тип безопасности:** `REALITY`
*   **Маскировка (SNI):** `www.microsoft.com`
*   **Flow:** `xtls-rprx-vision` (рекомендуется для стабильности)
*   **Ключи REALITY:**
    *   **Public Key:** `n5E8KcFHjef-ZC2mKjzkVldLJiLrsjfpE1Z-XmLfxH4`
    *   **Private Key:** Защищен (см. `ALL_CREDENTIALS.md`)

### Пользовательские настройки:
*   **UUID:** `eb4a1cf2-4235-4b0a-83b2-0e5a298389ed`
*   **Ссылка:** `vless://{uuid}@{ip}:443?type=tcp&security=reality&sni=www.microsoft.com&fp=chrome&flow=xtls-rprx-vision#VLESS-Reality`

---

## 🔌 Прокси-сервис (TinyProxy)

Используется для предоставления доступа к OpenAI API для внешних или внутренних модулей (например, MarketingBot).

*   **Порт:** `8080`
*   **Авторизация:** root:`LEJ6U5chSK`
*   **Тип:** HTTP/HTTPS
*   **Использование в .env:**
    ```bash
    HTTP_PROXY=http://root:LEJ6U5chSK@37.1.212.51:8080
    HTTPS_PROXY=http://root:LEJ6U5chSK@37.1.212.51:8080
    ```

---

## 📦 Модульность и управление

Система спроектирована так, чтобы модули могли работать независимо.

### Управление Marzban (VPN):
```bash
cd /opt/marzban
docker compose up -d      # Запуск
docker compose restart    # Перезапуск
docker compose down       # Остановка
```

### Управление TinyProxy:
```bash
sudo systemctl status tinyproxy
sudo systemctl restart tinyproxy
```

### Управление Файрволом (UFW):
Порты открываются/закрываются независимо:
```bash
sudo ufw allow 443/tcp    # Открыть VPN
sudo ufw allow 8080/tcp   # Открыть Proxy
```

---

## 📱 Клиентская настройка

Для подключения конечных устройств рекомендуется использовать:
1.  **Amnezia VPN** (Windows, macOS, iOS, Android) — наиболее простая настройка через импорт ссылки.
2.  **v2rayNG** (Android) / **Shadowrocket** (iOS).
3.  **V2RayN** (Windows).

---

## 🛡️ Безопасность и бэкапы

### Меры защиты:
*   **REALITY:** Защищает от активного сканирования (сервер притворяется Microsoft).
*   **UFW:** Файрвол разрешает только явно указанные порты (22, 443, 8080, 8000).
*   **SSH Tunnel:** Панель управления Marzban доступна только через SSH-туннель (localhost:8000).

### Резервное копирование:
Критические данные для бэкапа:
1.  `/var/lib/marzban/db.sqlite3` — база данных пользователей.
2.  `/var/lib/marzban/xray_config.json` — детальная конфигурация Xray.
3.  `/opt/marzban/.env` — настройки панели.

---

## 🛠️ Устранение неполадок

| Проблема | Команда проверки | Решение |
| :--- | :--- | :--- |
| Нет подключения к VPN | `netstat -tlnp \| grep 443` | Перезапустить Marzban |
| Бот не видит OpenAI | `curl -x ... https://api.openai.com` | Перезапустить TinyProxy |
| Панель не открывается | `docker ps \| grep marzban` | Проверить статус контейнера и туннеля |

---
**Документация актуальна на:** 21 января 2026
