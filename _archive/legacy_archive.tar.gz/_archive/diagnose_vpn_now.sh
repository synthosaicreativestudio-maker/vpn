#!/bin/bash

# Диагностика VPN - выполните в терминале панели is*hosting

echo "=========================================="
echo "🔍 ДИАГНОСТИКА VPN"
echo "=========================================="
echo ""

# 1. Проверка Docker контейнеров
echo "1️⃣  Docker контейнеры:"
echo "----------------------------------------"
docker ps -a | grep marzban || echo "❌ Контейнер Marzban не найден"
echo ""

# 2. Проверка порта 443
echo "2️⃣  Порт 443:"
echo "----------------------------------------"
netstat -tlnp | grep 443 || ss -tlnp | grep 443 || echo "❌ Порт 443 не слушается"
echo ""

# 3. Статус Docker
echo "3️⃣  Статус Docker:"
echo "----------------------------------------"
systemctl is-active docker && echo "✅ Docker активен" || echo "❌ Docker не активен"
echo ""

# 4. Логи Marzban (последние 30 строк)
echo "4️⃣  Логи Marzban:"
echo "----------------------------------------"
docker logs marzban-marzban-1 --tail 30 2>&1 | head -40 || echo "❌ Не удалось получить логи"
echo ""

# 5. Файрвол
echo "5️⃣  Файрвол (UFW):"
echo "----------------------------------------"
ufw status | grep -E "443|Status" || echo "⚠️  UFW не настроен или не активен"
echo ""

# 6. Конфигурация Xray
echo "6️⃣  Конфигурация VLESS Reality:"
echo "----------------------------------------"
if [ -f /var/lib/marzban/xray_config.json ]; then
    if grep -q "VLESS-Reality" /var/lib/marzban/xray_config.json 2>/dev/null; then
        echo "✅ VLESS Reality конфигурация найдена"
    else
        echo "❌ VLESS Reality конфигурация НЕ найдена"
    fi
else
    echo "❌ Файл конфигурации не существует"
fi
echo ""

# 7. Процесс xray
echo "7️⃣  Процесс Xray:"
echo "----------------------------------------"
ps aux | grep xray | grep -v grep || echo "❌ Процесс Xray не запущен"
echo ""

echo "=========================================="
echo "✅ Диагностика завершена"
echo "=========================================="
echo ""
echo "📋 Скопируйте весь вывод и отправьте для анализа"
