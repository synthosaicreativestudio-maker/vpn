#!/bin/bash

# Ручная диагностика сервера (запускать после получения SSH доступа)
# Использование: ./check_server_manual.sh

SERVER_IP="37.1.212.51"

echo "=========================================="
echo "🔍 РУЧНАЯ ДИАГНОСТИКА VPN СЕРВЕРА"
echo "=========================================="
echo ""
echo "Подключение к серверу: $SERVER_IP"
echo ""

# Выполнение команд на сервере
ssh root@$SERVER_IP << 'EOF'

echo "1️⃣  Проверка Docker контейнеров:"
echo "----------------------------------------"
docker ps | grep marzban || echo "❌ Контейнер не найден"
echo ""

echo "2️⃣  Все Docker контейнеры:"
echo "----------------------------------------"
docker ps -a
echo ""

echo "3️⃣  Проверка порта 443:"
echo "----------------------------------------"
netstat -tlnp | grep 443 || ss -tlnp | grep 443 || echo "❌ Порт 443 не слушается"
echo ""

echo "4️⃣  Статус Docker сервиса:"
echo "----------------------------------------"
systemctl status docker --no-pager | head -5
echo ""

echo "5️⃣  Статус файрвола (UFW):"
echo "----------------------------------------"
ufw status
echo ""

echo "6️⃣  Последние логи Marzban (30 строк):"
echo "----------------------------------------"
docker logs marzban-marzban-1 --tail 30 2>&1 || echo "❌ Не удалось получить логи"
echo ""

echo "7️⃣  Проверка конфигурации VLESS Reality:"
echo "----------------------------------------"
if [ -f /var/lib/marzban/xray_config.json ]; then
    if grep -q "VLESS-Reality" /var/lib/marzban/xray_config.json; then
        echo "✅ VLESS Reality конфигурация найдена"
        echo "Фрагмент конфигурации:"
        cat /var/lib/marzban/xray_config.json | python3 -m json.tool 2>/dev/null | grep -A 15 "VLESS-Reality" | head -20
    else
        echo "❌ VLESS Reality конфигурация не найдена"
    fi
else
    echo "❌ Файл конфигурации не существует"
fi
echo ""

echo "8️⃣  Проверка процесса xray:"
echo "----------------------------------------"
ps aux | grep xray | grep -v grep || echo "❌ Процесс xray не найден"
echo ""

echo "=========================================="
echo "✅ Диагностика завершена"
echo "=========================================="

EOF
