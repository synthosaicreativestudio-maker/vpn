# 🔍 Диагностика VPN - Инструкция

## Что нужно сделать:

1. **Откройте панель is*hosting**
2. **Перейдите на вкладку "Терминал"** (уже открыта в вашей панели)
3. **Скопируйте и выполните команды ниже**

---

## Быстрая диагностика (скопируйте все):

```bash
echo "=== 1. DOCKER КОНТЕЙНЕРЫ ===" && \
docker ps -a | grep marzban && \
echo "" && \
echo "=== 2. ПОРТ 443 ===" && \
(netstat -tlnp | grep 443 || ss -tlnp | grep 443 || echo "❌ Порт 443 не слушается") && \
echo "" && \
echo "=== 3. СТАТУС DOCKER ===" && \
systemctl is-active docker && \
echo "" && \
echo "=== 4. ЛОГИ MARZBAN (последние 20 строк) ===" && \
docker logs marzban-marzban-1 --tail 20 2>&1 && \
echo "" && \
echo "=== 5. ФАЙРВОЛ ===" && \
ufw status && \
echo "" && \
echo "=== 6. КОНФИГУРАЦИЯ ===" && \
(test -f /var/lib/marzban/xray_config.json && echo "✅ Файл существует" || echo "❌ Файл не существует") && \
(grep -q "VLESS-Reality" /var/lib/marzban/xray_config.json 2>/dev/null && echo "✅ VLESS Reality найден" || echo "❌ VLESS Reality не найден")
```

---

## Или выполните команды по отдельности:

### 1. Проверка Docker контейнеров
```bash
docker ps -a
```

### 2. Проверка порта 443
```bash
netstat -tlnp | grep 443
```

### 3. Логи Marzban
```bash
docker logs marzban-marzban-1 --tail 50
```

### 4. Статус Docker
```bash
systemctl status docker
```

### 5. Файрвол
```bash
ufw status
```

---

## После выполнения:

**Скопируйте весь вывод** и отправьте мне - я смогу точно определить проблему и предложить решение.

---

## Возможные проблемы и быстрые исправления:

### Если контейнер остановлен:
```bash
cd /opt/marzban
docker compose restart
```

### Если Docker не запущен:
```bash
systemctl start docker
cd /opt/marzban
docker compose up -d
```

### Если порт 443 закрыт в файрволе:
```bash
ufw allow 443/tcp
ufw reload
```
