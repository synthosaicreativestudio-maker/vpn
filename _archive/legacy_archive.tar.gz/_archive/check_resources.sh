#!/bin/bash

# Скрипт для проверки использования ресурсов сервера
# Запустите через терминал в панели is*hosting или через SSH

echo "=========================================="
echo "📊 ИСПОЛЬЗОВАНИЕ РЕСУРСОВ СЕРВЕРА"
echo "=========================================="
echo ""

# 1. Использование диска
echo "💾 ИСПОЛЬЗОВАНИЕ ДИСКА:"
echo "----------------------------------------"
df -h / | awk 'NR==1 || /\/$/'
echo ""

# 2. Использование RAM
echo "🧠 ИСПОЛЬЗОВАНИЕ ОЗУ (RAM):"
echo "----------------------------------------"
free -h
echo ""

# 3. Использование CPU
echo "⚙️  ИСПОЛЬЗОВАНИЕ CPU:"
echo "----------------------------------------"
echo "Загрузка CPU за 1, 5, 15 минут:"
uptime | awk -F'load average:' '{print $2}'
echo ""
echo "Топ процессов по использованию CPU:"
ps aux --sort=-%cpu | head -6 | awk '{printf "%-8s %6s%% %s\n", $1, $3, $11}'
echo ""

# 4. Использование трафика (если установлен vnstat)
echo "🌐 ИСПОЛЬЗОВАНИЕ ТРАФИКА:"
echo "----------------------------------------"
if command -v vnstat &> /dev/null; then
    vnstat -d
    echo ""
    vnstat -m
else
    echo "⚠️  vnstat не установлен. Установите: apt install vnstat"
    echo "Текущий трафик можно посмотреть в панели is*hosting"
fi
echo ""

# 5. Использование Docker
echo "🐳 ИСПОЛЬЗОВАНИЕ DOCKER:"
echo "----------------------------------------"
if command -v docker &> /dev/null; then
    docker system df 2>/dev/null || echo "Docker не запущен или нет прав"
else
    echo "Docker не установлен"
fi
echo ""

# 6. Размер логов
echo "📝 РАЗМЕР ЛОГОВ:"
echo "----------------------------------------"
du -sh /var/log/* 2>/dev/null | sort -hr | head -5
echo ""

# 7. Размер Docker данных
echo "🐳 РАЗМЕР DOCKER ДАННЫХ:"
echo "----------------------------------------"
if [ -d /var/lib/docker ]; then
    du -sh /var/lib/docker 2>/dev/null
fi
if [ -d /var/lib/marzban ]; then
    echo "Marzban данные:"
    du -sh /var/lib/marzban 2>/dev/null
fi
echo ""

echo "=========================================="
echo "✅ Проверка завершена"
echo "=========================================="
