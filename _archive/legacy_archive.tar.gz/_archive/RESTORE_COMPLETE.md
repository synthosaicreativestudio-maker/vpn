# ✅ Восстановление Smart-VPN завершено

**Дата:** 21 января 2026  
**Статус:** ✅ Конфигурация восстановлена

---

## 📋 Выполненные работы

### 1. ✅ Конфигурация Xray Core
- **Маскировка:** `taxi.yandex.ru:443` ✅
- **Server Names:** `["taxi.yandex.ru", "ya.ru", "yandex.ru"]` ✅
- **Flow:** `xtls-rprx-vision` ✅
- **Port:** `443` ✅
- **Public Key:** `n5E8KcFHjef-ZC2mKjzkVldLJiLrsjfpE1Z-XmLfxH4` ✅

### 2. ✅ Шаблон подписки Marzban
- **Файл:** `/var/lib/marzban/templates/clash/smart-routing.yml`
- **Формат:** Clash Meta YAML ✅
- **SNI:** `taxi.yandex.ru` ✅
- **Правила маршрутизации:**
  - Госуслуги → DIRECT ✅
  - Банки → DIRECT ✅
  - `.ru` домены → DIRECT ✅
  - Российские IP → DIRECT ✅
  - Остальное → VPN ✅

### 3. ✅ Настройки .env
- `CUSTOM_TEMPLATES_DIRECTORY=/var/lib/marzban/templates/` ✅
- `CLASH_SUBSCRIPTION_TEMPLATE=clash/smart-routing.yml` ✅
- `XRAY_SUBSCRIPTION_URL_PREFIX=https://37.1.212.51.sslip.io` ✅

### 4. ✅ Конфигурация Nginx
- **Файл:** `/etc/nginx/sites-available/marzban`
- **Заголовки для Happ:**
  - `Content-Type: text/yaml` ✅
  - `Subscription-Userinfo: upload=0; download=0; total=53687091200; expire=0` ✅
  - `Access-Control-Allow-Origin: *` ✅

---

## 🔍 Проверка работоспособности

### Проверка 1: Curl с User-Agent Happ

```bash
curl -H "User-Agent: Happ" https://37.1.212.51.sslip.io/sub/{USERNAME}/clash
```

**Ожидаемый результат:**
- HTTP 200 OK
- Content-Type: text/yaml
- Subscription-Userinfo заголовок присутствует
- YAML содержит секцию `proxies` с заполненными данными

### Проверка 2: Проверка IP

```bash
# Подключитесь через VPN и проверьте IP
curl https://ifconfig.me
# Должен вернуть: 37.1.212.51
```

### Проверка 3: Проверка доступа к Госуслугам

```bash
# При подключенном VPN
curl -I https://gosuslugi.ru
# Должен работать напрямую (без VPN)
```

---

## 📝 Важные замечания

### Пользователь в Marzban

⚠️ **Важно:** Убедитесь, что пользователь существует в Marzban!

1. Подключитесь к Marzban через SSH туннель:
   ```bash
   ssh -L 8000:127.0.0.1:8000 root@37.1.212.51
   ```

2. Откройте в браузере: `http://localhost:8000`

3. Создайте пользователя (если не существует):
   - Username: `vera` (или любой другой)
   - Protocol: `VLESS`
   - Flow: `vision` (xtls-rprx-vision)
   - Inbound: `VLESS_IN` (или соответствующий inbound)

4. Скопируйте ссылку подписки из Marzban

### Формат URL подписки

Marzban использует формат:
```
https://37.1.212.51.sslip.io/sub/{TOKEN}/clash
```

Где `{TOKEN}` - это base64 закодированный токен пользователя (обычно содержит username и другие данные).

---

## 🔧 Параметры подключения

### VLESS + REALITY

```
vless://eb4a1cf2-4235-4b0a-83b2-0e5a298389ed@37.1.212.51:443?type=tcp&security=reality&sni=taxi.yandex.ru&pbk=n5E8KcFHjef-ZC2mKjzkVldLJiLrsjfpE1Z-XmLfxH4&fp=chrome&flow=xtls-rprx-vision#Smart-VPN-Yandex
```

**Параметры:**
- **Protocol:** VLESS
- **Server:** 37.1.212.51
- **Port:** 443
- **UUID:** eb4a1cf2-4235-4b0a-83b2-0e5a298389ed
- **Flow:** xtls-rprx-vision
- **SNI:** taxi.yandex.ru
- **Public Key:** n5E8KcFHjef-ZC2mKjzkVldLJiLrsjfpE1Z-XmLfxH4
- **Short ID:** "" (пустой)

---

## 🛠️ Устранение проблем

### Проблема: "Error 39" в Happ

**Причина:** Пустой список серверов в подписке

**Решение:**
1. Убедитесь, что пользователь существует в Marzban
2. Убедитесь, что пользователь привязан к правильному inbound (VLESS_IN)
3. Проверьте шаблон подписки: `/var/lib/marzban/templates/clash/smart-routing.yml`
4. Перезапустите Marzban: `docker compose restart` в `/opt/marzban`

### Проблема: "Unknown Content Type"

**Причина:** Неправильный Content-Type заголовок

**Решение:**
1. Проверьте конфигурацию Nginx: `/etc/nginx/sites-available/marzban`
2. Убедитесь, что заголовок `Content-Type: text/yaml` установлен
3. Перезагрузите Nginx: `systemctl reload nginx`

### Проблема: Подписка возвращает 404

**Причина:** Пользователь не существует или неправильный токен

**Решение:**
1. Создайте пользователя в Marzban
2. Используйте правильный токен из Marzban UI
3. Проверьте формат URL подписки

---

## 📊 Чек-лист проверки

- [x] Конфигурация Xray использует `taxi.yandex.ru:443`
- [x] Шаблон подписки создан и загружен
- [x] Nginx настроен с правильными заголовками
- [x] Marzban перезапущен
- [ ] Пользователь создан в Marzban
- [ ] Подписка возвращает валидный YAML
- [ ] Happ приложение принимает подписку без ошибок
- [ ] VPN подключается и работает
- [ ] Госуслуги доступны напрямую (без VPN)

---

## 📞 Дополнительная информация

### Логи Marzban

```bash
docker logs marzban -f
```

### Логи Nginx

```bash
tail -f /var/log/nginx/error.log
```

### Проверка конфигурации Xray

```bash
cat /var/lib/marzban/xray_config.json | python3 -m json.tool | grep -A 30 "VLESS_IN"
```

---

**Восстановление выполнено:** 21 января 2026  
**Версия конфигурации:** Smart-VPN (Reality + Yandex Masking)
